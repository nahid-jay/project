<?php 
	session_start();
	// mysql database connection
	const DB_NAME = 'pictogram';
	const DB_HOST = 'localhost';
	const DB_USER = 'root';
	const DB_PASS = '';
 ?>