<?php 
	require_once 'functions.php';

//for menaging sign-up
	if (isset($_GET['signup'])) {
		// code...
		$response=validateSignupForm($_POST);
		if ($response['status']) {
			// code...
			if (createUser($_POST)) {
				// code...
				header('location:../../?login&newuser');
			}else{
				echo "<script>alart('something is wrong')</script>";
			}

		}else{
			$_SESSION['error']=$response;
			$_SESSION['fromdata']=$_POST;
			header("location:../../?signup");
		}
	}


//for menaging login
	if (isset($_GET['login'])) {
		// code...
		$response=validateLoginForm($_POST);
		if ($response['status']) {
			// code...
			$_SESSION['Auth'] = true;
			$_SESSION['userdata'] = $response['user'];
			header("location:../../");
		}else{
			$_SESSION['error']=$response;
			$_SESSION['fromdata']=$_POST;
			header("location:../../?login");
		}
	}
 ?>