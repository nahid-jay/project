<?php
include_once 'database.php';
$result = mysqli_query($conn, "SELECT * FROM user");
?>
<!doctype html>
<html lang="en">
<head>
    <title>Retrive data</title>
</head>
<body>
<?php
if(mysqli_num_rows($result) > 0){
    ?>
    <table>
        <tr>
            <td>Sl No</td>
            <td>Username</td>
            <td>E-mail</td>
            <td>Password</td>
            <td>Profile_Pic</td>
            <td>Created_at</td>
            <td>Update_at</td>
        </tr>
        <?php
        $i = 0;
        while ($row = mysqli_fetch_array($result)){
            ?>
            <tr>
                <td><?php echo $row["id"]; ?></td>
                <td><?php echo $row["username"]; ?></td>
                <td><?php echo $row["email"]; ?></td>
                <td><?php echo $row["password"]; ?></td>
                <td><?php echo $row["profile_pic"]; ?></td>
                <td><?php echo $row["created_at"]; ?></td>
                <td><?php echo $row["update_at"]; ?></td>
            </tr>
            <?php
            $i++;
        }
        ?>
    </table>
    <?php
}
else{
    echo "No result found!";
}
?>
</body>
</html>
