<!-- -->
    <div class="login">
        <div class="col-4 bg-white border rounded p-4 shadow-sm">
            <form method="post" action="assets/php/actions.php?signup">
                <div class="d-flex justify-content-center"> 
                    <h1 class="h5 mb-3 fw-normal" style="font-size:20px; color: rgb(186, 220, 88);"><b>Sign up</b></h1>
                <br>
                </div>
                <h1 class="h5 mb-3 fw-normal" style="font-size: 15px; color: green;">Create new account</h1>
                
                <h3 style="font-size: 15px; color:green;"><b>Username</b></h3>
                <div class="form-floating mt-1">
                    <input type="text" name="username" class="form-control rounded-0" placeholder="username">
                    <label for="floatingInput">username</label>
                </div>
                <?=showError('username')?>
                <br>
                
                <h3 style="font-size: 15px; color:green;"><b>Email</b></h3>
                <div class="form-floating mt-1">
                    <input type="email" name="email" class="form-control rounded-0" placeholder="username/email">
                    <label for="floatingInput">email</label>
                </div>
                <?=showError('email')?>
                <br>

                <h3 style="font-size: 15px; color:green;"><b>Password</b></h3>
                <div class="form-floating mt-1">
                    <input type="password" name="password" class="form-control rounded-0" id="floatingPassword" placeholder="Password">
                    <label for="floatingPassword">password</label>
                </div>
                <?=showError('password')?>

                <div class="mt-3 d-flex justify-content-between align-items-center">
                    <button class="btn btn-primary" type="submit" style="font-size:15px; background-color:green; border:none;">Sign Up</button>

                    <a href="?login" class="text-decoration-none" style="font-size: 15px; color: green;">Already have an account ?</a>
                </div>

            </form>
        </div>
    </div>


    