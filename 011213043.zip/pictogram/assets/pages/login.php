
    <div class="login">
        <div class="col-4 bg-white border rounded p-4 shadow-sm">
            <form method="post" action="assets/php/actions.php?login">
                <h1 style="font-size: 50px; color: rgb(186, 220, 88);"><center><b>carbX</b></center></h1>
                
                <h5 style="font-size: 15px; color:green;"><b><center>A place to know about carbon footprint</center></b></h5>
                <br>
                <h1 class="h5 mb-3 fw-normal" style="font-size:20px; color: rgb(186, 220, 88);"><b>Login</b></h1>
                

                <h3 style="font-size: 15px; color:green;"><b>Email</b></h3>
                <div class="form-floating">
                    <input type="text" name="username_email" class="form-control rounded-0" placeholder="username/email" required>
                    <label for="floatingInput">username/email</label>
                </div>
                <?=showError('username_email')?>

                <br>
                <h3 style="font-size: 15px; color:green;"><b>Password</b></h3>
                <div class="form-floating mt-1">
                    <input type="password" name="password" class="form-control rounded-0" id="floatingPassword" placeholder="Password" required>
                    <label for="floatingPassword">Password</label>
                </div>
                <?=showError('password')?>
                <?=showError('checkuser')?>


                <div class="mt-3 d-flex justify-content-between align-items-center">
                    <button class="btn btn-primary" type="submit" style="font-size:15px; background-color:green; border:none;">Login</button>
                    <a href="?signup" class="text-decoration-none" style="font-size:15px;color: green;">Create New Account</a>


                </div>
                
                    <a href="#" class="text-decoration-none">Forgot password ?</a>
                
            </form>
        </div>
    </div>
