<?php
$servername='localhost';
$username='root';
$password='';
$dbname="pictogram";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
if(!$conn){
    die('Could not connect My Sql:' .mysqli_error());
}
?>
