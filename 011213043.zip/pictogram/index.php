<?php 
	require_once 'assets/php/functions.php';

	if (isset($_SESSION['Auth'])) {
		// code...
		echo "user is logged in";
		$userdata = $_SESSION['userdata'];
		echo "<pre>";
		print_r($userdata);
	}elseif (isset($_GET['signup'])) {
		// code...
			showPage('header',['page_title'=>'pictogram - SignUp']);
			showPage('signup');
			
	}elseif (isset($_GET['login'])) {
		// code...
		showPage('header',['page_title'=>'pictogram - Login']);
		showPage('login');
	}else{
		showPage('header',['page_title'=>'pictogram - Login']);
		showPage('login');
	}

	showPage('footer');
	unset($_SESSION['error']);
	unset($_SESSION['fromdata']);
 ?>